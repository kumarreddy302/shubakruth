/*
 * Main JavaScript file for Shubhakruth Medical Genetics
 * This file contains all dynamic functionality for the site.
 */
document.addEventListener("DOMContentLoaded", function() {
    
    // Initialize all components
    initTopBanner();
    initMobileNav();
    initTypingAnimation();
    initAuthForms();
    initServiceFilters();
    initAdminTabs();
    initImageModal();
    initSeamlessScrollers();

});

/**
 * 1. Top Announcement Banner
 * Handles the 'x' close button on the top-most scrolling banner.
 */
function initTopBanner() {
    const banner = document.getElementById('top-banner');
    const closeBtn = document.getElementById('close-banner-btn');

    // Only run if the banner and button exist on the page
    if (banner && closeBtn) {
        closeBtn.addEventListener('click', function() {
            banner.style.display = 'none';
        });
    }
}

/**
 * 2. Mobile Navigation
 * Toggles the main navigation menu and handles dropdown submenus on mobile.
 */
function initMobileNav() {
    const mobileNavToggle = document.querySelector('.mobile-nav-toggle');
    if (mobileNavToggle) {
        const primaryNav = document.querySelector('.nav-links');
        
        // Main menu toggle
        mobileNavToggle.addEventListener('click', () => {
            const isVisible = primaryNav.getAttribute('data-visible') === 'true';
            primaryNav.setAttribute('data-visible', !isVisible);
            mobileNavToggle.setAttribute('aria-expanded', !isVisible);
            
            // Toggle hamburger icon
            const icon = mobileNavToggle.querySelector('i');
            if (icon) {
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-times');
            }
        });

        // Dropdown toggle
        const dropdownItems = document.querySelectorAll('.has-dropdown > a');
        dropdownItems.forEach(item => {
            item.addEventListener('click', (event) => {
                // Only prevent default and toggle if in mobile view
                if (window.innerWidth <= 1024) { 
                    event.preventDefault();
                    item.parentElement.classList.toggle('open');
                }
            });
        });
    }
}

/**
 * 3. Title Bar Typewriter Animation
 * Animates the subheadings on the homepage title bar.
 */
function initTypingAnimation() {
    const changingTextElement = document.getElementById("changing-text");
    const subheadingDataElement = document.getElementById("subheading-data");

    if (changingTextElement && subheadingDataElement) {
        let subheadings = [];
        try {
            subheadings = JSON.parse(subheadingDataElement.textContent);
        } catch (e) {
            console.error("Error parsing subheadings from JSON:", e);
            subheadings = ["MEDICAL GENETICS"]; // Fallback text
        }

        if (subheadings.length > 0) {
            let currentTextIndex = 0;
            let charIndex = 0;
            let isDeleting = false;
            let typingSpeed = 100;
            let deletingSpeed = 50;
            let delayBetweenSubheadings = 2000;

            function typeWriterEffect() {
                const currentHeading = subheadings[currentTextIndex];
                let speed;

                if (isDeleting) {
                    // Deleting text
                    changingTextElement.textContent = currentHeading.substring(0, charIndex - 1);
                    charIndex--;
                    speed = deletingSpeed;
                } else {
                    // Typing text
                    changingTextElement.textContent = currentHeading.substring(0, charIndex + 1);
                    charIndex++;
                    speed = typingSpeed;
                }

                if (!isDeleting && charIndex === currentHeading.length) {
                    // Word is fully typed, pause, then start deleting
                    speed = delayBetweenSubheadings;
                    isDeleting = true;
                } else if (isDeleting && charIndex === 0) {
                    // Word is fully deleted, move to next word
                    isDeleting = false;
                    currentTextIndex = (currentTextIndex + 1) % subheadings.length;
                    speed = 500; // Pause before new word
                }
                
                setTimeout(typeWriterEffect, speed);
            }
            
            // Start the animation
            typeWriterEffect();
        }
    }
}

/**
 * 4. Auth Form Toggle
 * Toggles between the Login and Register forms on the auth page.
 */
function initAuthForms() {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const showRegisterLink = document.getElementById('show-register');
    const showLoginLink = document.getElementById('show-login');

    if (loginForm && registerForm && showRegisterLink && showLoginLink) {
        showRegisterLink.addEventListener('click', (e) => {
            e.preventDefault();
            loginForm.classList.add('hidden');
            registerForm.classList.remove('hidden');
        });
        
        showLoginLink.addEventListener('click', (e) => {
            e.preventDefault();
            registerForm.classList.add('hidden');
            loginForm.classList.remove('hidden');
        });
    }
}

/**
 * 5. Service Filter & Search
 * Filters services on the services page based on search and category.
 */
function initServiceFilters() {
    const searchInput = document.getElementById('service-search');
    const categoryFilter = document.getElementById('category-filter');
    const servicesGrid = document.getElementById('services-grid');

    if (servicesGrid && (searchInput || categoryFilter)) {
        const noResultsMessage = document.getElementById('no-results-message');

        function filterServices() {
            const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
            const selectedCategory = categoryFilter ? categoryFilter.value : 'all';
            const serviceCards = servicesGrid.querySelectorAll('.service-card');
            let visibleCount = 0;

            serviceCards.forEach(card => {
                const cardName = card.getAttribute('data-name').toLowerCase();
                const cardCategory = card.getAttribute('data-category');
                
                const nameMatch = cardName.includes(searchTerm);
                const categoryMatch = (selectedCategory === 'all') || (cardCategory === selectedCategory);
                
                if (nameMatch && categoryMatch) {
                    card.classList.remove('hidden');
                    visibleCount++;
                } else {
                    card.classList.add('hidden');
                }
            });
            
            if (noResultsMessage) {
                noResultsMessage.classList.toggle('hidden', visibleCount > 0);
            }
        }
        
        if (searchInput) {
            searchInput.addEventListener('keyup', filterServices);
        }
        if (categoryFilter) {
            categoryFilter.addEventListener('change', filterServices);
        }
    }
}

/**
 * 6. Admin Dashboard Tabs
 * Handles the tabbed interface in the admin dashboard.
 */
function initAdminTabs() {
    const adminTabsContainer = document.querySelector('.admin-tabs');
    if (adminTabsContainer) {
        const tabLinks = adminTabsContainer.querySelectorAll('.tab-link');
        const tabContents = document.querySelectorAll('.tab-content');

        tabLinks.forEach(link => {
            link.addEventListener('click', function() {
                // Deactivate all
                tabLinks.forEach(l => l.classList.remove('active'));
                tabContents.forEach(c => c.style.display = 'none');
                
                // Activate clicked
                this.classList.add('active');
                const tabId = this.getAttribute('data-tab');
                const content = document.getElementById(tabId);
                if (content) {
                    content.style.display = 'block';
                }
            });
        });
        
        // Activate the first tab by default
        if (tabLinks.length > 0) {
            tabLinks[0].click(); 
        }
    }
}

/**
 * 7. Image Popup Modal
 * Shows the popup modal on page load and handles closing it.
 */
function initImageModal() {
    const modal = document.getElementById("image-popup-modal");
    
    if (modal) {
        const closeBtn = modal.querySelector(".modal-close-btn");

        function closeModal() {
          modal.style.display = "none";
        }

        // Show the modal on page load (as per your file)
        modal.style.display = "flex";

        // Close when clicking the (x)
        if (closeBtn) {
            closeBtn.onclick = closeModal;
        }

        // Close when clicking the background overlay
        modal.onclick = function(event) {
          if (event.target == modal) {
            closeModal();
          }
        }
    }
}

/**
 * 8. Seamless Scroller Duplication
 * Finds all scrolling galleries and duplicates their content for a smooth,
 * infinite loop animation provided by the CSS.
 */
function initSeamlessScrollers() {
    const scrollers = document.querySelectorAll('.scroll-viewport, .scroll-gallery');

    scrollers.forEach(scroller => {
        const track = scroller.querySelector('.scroll-track');
        if (track) {
            // Get all items
            const items = Array.from(track.children);
            
            // Clone each item and append it
            items.forEach(item => {
                const clone = item.cloneNode(true);
                track.appendChild(clone);
            });
        }
    });
}